---
name: Community Housing Support System
colors:
  surface: '#f8f9ff'
  surface-dim: '#cbdbf5'
  surface-bright: '#f8f9ff'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#eff4ff'
  surface-container: '#e5eeff'
  surface-container-high: '#dce9ff'
  surface-container-highest: '#d3e4fe'
  on-surface: '#0b1c30'
  on-surface-variant: '#434655'
  inverse-surface: '#213145'
  inverse-on-surface: '#eaf1ff'
  outline: '#737686'
  outline-variant: '#c3c6d7'
  surface-tint: '#0053db'
  primary: '#004ac6'
  on-primary: '#ffffff'
  primary-container: '#2563eb'
  on-primary-container: '#eeefff'
  inverse-primary: '#b4c5ff'
  secondary: '#006c49'
  on-secondary: '#ffffff'
  secondary-container: '#6cf8bb'
  on-secondary-container: '#00714d'
  tertiary: '#784b00'
  on-tertiary: '#ffffff'
  tertiary-container: '#996100'
  on-tertiary-container: '#ffeedd'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#dbe1ff'
  primary-fixed-dim: '#b4c5ff'
  on-primary-fixed: '#00174b'
  on-primary-fixed-variant: '#003ea8'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ffddb8'
  tertiary-fixed-dim: '#ffb95f'
  on-tertiary-fixed: '#2a1700'
  on-tertiary-fixed-variant: '#653e00'
  background: '#f8f9ff'
  on-background: '#0b1c30'
  surface-variant: '#d3e4fe'
typography:
  display:
    fontFamily: Be Vietnam Pro
    fontSize: 48px
    fontWeight: '700'
    lineHeight: 56px
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-lg-mobile:
    fontFamily: Be Vietnam Pro
    fontSize: 28px
    fontWeight: '700'
    lineHeight: 36px
  headline-md:
    fontFamily: Be Vietnam Pro
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Be Vietnam Pro
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Be Vietnam Pro
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-md:
    fontFamily: Be Vietnam Pro
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 20px
    letterSpacing: 0.01em
  label-sm:
    fontFamily: Be Vietnam Pro
    fontSize: 12px
    fontWeight: '500'
    lineHeight: 16px
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  base: 4px
  xs: 8px
  sm: 16px
  md: 24px
  lg: 40px
  xl: 64px
  gutter: 24px
  margin-mobile: 16px
  margin-desktop: auto
  max-width: 1280px
---

## Brand & Style

This design system is built to foster trust, accessibility, and a sense of belonging for the Vietnamese community seeking housing support. The brand personality is **compassionate yet professional**, balancing the warmth of community with the reliability of a formal support network.

The design style follows a **Modern Corporate** aesthetic with a **Soft Minimalist** twist. It prioritizes clarity and ease of use through generous whitespace, high-contrast typography, and subtle depth. By avoiding visual clutter, the UI reduces the cognitive load for users who may be in high-stress situations. The emotional response should be one of "calm confidence"—reassuring users that they are in a safe, organized, and helpful environment.

## Colors

The palette is rooted in a professional "Trustworthy Blue" to establish authority and reliability. This is complemented by "Soft Green," which symbolizes growth, safety, and the concept of "home." 

- **Primary (Blue):** Used for main actions, navigation headers, and primary buttons to signal importance and trust.
- **Secondary (Green):** Used for success states, growth indicators, and community-centric features.
- **Tertiary (Amber):** Used sparingly for highlights or non-urgent warnings, providing warmth to the interface.
- **Neutral:** A range of slate greys ensures high legibility for text and subtle boundaries for UI elements.
- **Background:** A very light grey (#F9FAFB) is used instead of pure white to reduce eye strain and provide a soft canvas for card-based layouts.

## Typography

**Be Vietnam Pro** is selected as the sole typeface to ensure a cohesive and culturally resonant feel. It offers exceptional legibility for both English and Vietnamese characters, particularly for diacritics.

- **Headlines:** Bold weights and tight letter-spacing create a modern, editorial feel that guides the user's eye.
- **Body Text:** Use `body-md` for standard descriptive text. Ensure a maximum line length of 65-75 characters to maintain readability.
- **Labels:** Used for buttons, tags, and small metadata. These use a slightly heavier weight to remain distinct from body copy at smaller sizes.

## Layout & Spacing

The layout utilizes a **fluid grid system** that transitions into a centered **fixed max-width container** on large displays.

- **Desktop (1024px+):** A 12-column grid with 24px gutters. Content is contained within a 1280px max-width to prevent line lengths from becoming too long.
- **Tablet (768px - 1023px):** An 8-column grid with 20px gutters and 32px side margins.
- **Mobile (Up to 767px):** A 4-column grid with 16px gutters and 16px side margins.

Spacing follows an 8pt rhythm to ensure mathematical harmony across all components. Use `lg` (40px) or `xl` (64px) for vertical section spacing to maintain the "airy" and "friendly" brand feel.

## Elevation & Depth

This design system uses **Tonal Layers** combined with **Ambient Shadows** to create a sense of organized hierarchy. 

- **Level 0 (Background):** #F9FAFB. All main content lives here.
- **Level 1 (Cards/Containers):** Pure White (#FFFFFF) with a very soft, diffused shadow (Offset: 0, 4px; Blur: 20px; Opacity: 4% Black). This is used for standard content modules.
- **Level 2 (Interactive/Hover):** A slightly more pronounced shadow (Offset: 0, 8px; Blur: 30px; Opacity: 8% Black) to indicate interactivity.
- **Outlines:** Use 1px borders in a light neutral (#E2E8F0) for form fields and structural dividers instead of heavy shadows to keep the UI clean.

## Shapes

The shape language is defined by **Rounded** geometry to evoke friendliness and approachability. 

- **Standard Elements:** Cards, input fields, and containers use a 0.5rem (8px) radius.
- **Large Elements:** Featured banners or large sections use a 1rem (16px) radius.
- **Interactive Accents:** Buttons and tags use a "pill" style (Full rounded / `rounded-xl`) to provide a tactile, modern feel that differentiates clickable elements from static content.

## Components

### Buttons
- **Primary:** Solid Blue background, white text, pill-shaped.
- **Secondary:** Green border (2px), Green text, pill-shaped.
- **Ghost:** No background or border, Blue text. Used for less prominent actions.

### Input Fields
- White background with a 1px soft grey border. 
- On focus, the border changes to Primary Blue with a subtle 3px blue outer glow (low opacity).
- Labels are always positioned above the input for maximum accessibility.

### Cards
- White background, 8px corner radius, and Level 1 shadow. 
- Content inside cards should have at least 24px of internal padding (`spacing.md`).

### Chips & Tags
- Pill-shaped with a light tint of the category color (e.g., Light Green background with Dark Green text).
- Used for status indicators (e.g., "Available", "Approved").

### Lists
- Clean, unbordered lists with 16px vertical spacing between items. 
- Use icons (Soft Green) for bullet points in community-focused lists to add visual warmth.

### Community Specifics
- **Progress Steppers:** Use soft green to track housing application progress.
- **Resource Cards:** Feature large, legible headlines and a primary action button at the bottom.